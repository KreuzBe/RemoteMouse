package de.kreuzbe.movingMouse;

import de.kreuzbe.movingMouse.io.Listener;
import de.kreuzbe.movingMouse.net.Server;

public class Main {

    public static void main(String[] args) {
        Server s = new Server(4444);
        Listener l = new Listener(s);
    }

}
